import MenuIcon from '@mui/icons-material/Menu';
import CloseIcon from '@mui/icons-material/Close';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
const Navbar = () => {
    const {isAuthenticated, user } = useSelector((state) => state.user);
const [open,setOpen]=useState(false)
console.log(open);
  return (
    <>
        <div className="container-fluid">
        <header>
            <div className={`${open?"bg-black w-full":"w-full bg-[#009688]"}`}>
                <div className=" flex h-[15vh] ">
                    <div className="logo px-2 mt-2 lg:mt-[1.6rem]"> Kidz<span className="text-[yellow]">First</span></div>
                    <nav className="hidden lg:flex bg-[#009688] h-[15vh]">
  <ul className="flex items-center justify-between px-6 py-4">
    <li>
      <Link to={"/"} className="text-white font-bold text-xl">Home</Link>
    </li>
    <li>
      <Link to="/school-directory" className="text-white hover:text-gray-300 ml-8">School Directory</Link>
    </li>
    <li>
      <Link to={"/educational-resources"} className="text-white hover:text-gray-300 ml-8">Educational Resources</Link>
    </li>
    <li>
      <Link to={"/news-and-updates"} className="text-white hover:text-gray-300 ml-8">News and Updates</Link>
    </li>
    <li>
      <Link to={"/contact"} className="text-white hover:text-gray-300 ml-8">Contact Us</Link>
    </li>
   {!isAuthenticated&& <li>
      <Link to={"/login"} className="bg-secondary text-white hover:bg-secondary-dark py-2 px-4 rounded ml-8">
        Sign In
      </Link>
    </li>}
    {isAuthenticated && (
      <li>
        <Link to={"/login"} className="text-white hover:text-gray-300 mr-0">
          <img src={user.avatar ? user.avatar.url : ""} alt="" className="h-10 rounded-full" />
        </Link>
      </li>
    )}
  </ul>
</nav>

                <div className=' flex flex-col lg:hidden'>
                <div>
                {open?
                <CloseIcon
                style={{color:"white",
                margin:".1rem 1rem",
                fontSize:"3rem",
                marginLeft:open?"10rem":""
            }}
                onClick={()=>{
                    setOpen(!open)
                }}
                />
                :<MenuIcon 
                style={{color:"white",
                margin:".1rem 1rem",
                fontSize:"3rem",
                marginLeft:open?"10rem":""
            }}
                onClick={()=>{
                    setOpen(!open)
                }}
                />}

                </div>
                <div className=' z-50'>
                    {open&&  <ul className='lg:hidden flex flex-col bg-[black] rounded-[2rem] px-10 mt-[1rem] -ml-16'>
                        <li className='mt-[.5rem]' ><Link to={"/"} className="a text-white">Home</Link></li>
                        <li className='mt-[.5rem]'><Link to={"/school-directory"} className="a text-white">SchoolDiectory</Link></li>
                        <li className='mt-[.5rem]'><Link to={"/educational-resources"} className="a text-white">EducationalResources</Link></li>
                        <li className='mt-[.5rem]'><Link to={"/news-and-updates"} className="a text-white">NewsandUpdate</Link></li>
                        <li className='mt-[.5rem]'><Link to={"/contact"} className="a text-white">ContactUs</Link></li>
                        <li className='mt-[1rem] mb-6'><Link to={"/login"} className="button cursor-pointer">SignIn</Link></li>

                        
                    </ul>}
                </div>
                </div>
                </div>

            </div>
        </header>
    </div>
    </>
  )
}

export default Navbar