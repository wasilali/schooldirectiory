import React,{useState} from 'react'
import './Shipping.css'
import { useSelector,useDispatch } from 'react-redux'
import CheckoutSteps from "../Cart/ChackoutSteps"
import MetData from '../layout/MetData'
import PinDropIcon from '@material-ui/icons/PinDrop'
import HomeIcon from '@material-ui/icons/Home'
import LocationCityIcon from '@material-ui/icons/LocationCity'
import PublicIcon from '@material-ui/icons/Public'
import PhoneIcon from '@material-ui/icons/Phone'
import TransferWithinAStationIcon from '@material-ui/icons/TransferWithinAStation'
import { useAlert } from 'react-alert'
import {Country,State} from 'country-state-city'
import { useNavigate } from 'react-router-dom'
import { saveShippingInfo } from '../../actions/cartAction'

const Shipping = () => {
    const dispatch=useDispatch()
    const navigate=useNavigate()
    const alert =useAlert()
    const {shippingInfo} =useSelector((state) => state.cart)
    const [city,setCity] = useState(shippingInfo.city)
    const [address,setAdress] = useState(shippingInfo.address)
    const [state,setState] = useState(shippingInfo.state)
    const [country,setCountry] = useState(shippingInfo.country)
    const [pinCode,setPinCode] = useState(shippingInfo.pinCode)
    const [phoneNo,setPhoneNo] = useState(shippingInfo.setPhoneNo)

    const shippingSubmit=(e)=>{
       e.preventDefault()

       if(phoneNo.length < 11 || phoneNo.length > 11){
        alert.error("Phone Number should be 11 digits long")
        return
       }
       dispatch(
        saveShippingInfo({address,city,state,country,pinCode,phoneNo})

       )
       navigate('/order/confirm')
    }
    
  return (
    <>
    <MetData title="Shipping Details"/>
    <CheckoutSteps activeStep={0}/>
    <div className='shippingContainer'>
        <div className='shippingBox'>
        <h2 className='shippingHeading text-[tomato]'>Shipping Details</h2>
        <form 
         className='shippingForm'
         encType='multipart/form-data'
         onSubmit={shippingSubmit}
        >
        <div>
            <HomeIcon/>
            <input type="text" 
            placeholder='Adress'
            required
            value={address}
            onChange={(e)=>setAdress(e.target.value)}
            />
        </div>

        <div>
            <LocationCityIcon/>
            <input type="text" 
            placeholder='City'
            required
            value={city}
            onChange={(e)=>setCity(e.target.value)}
            />
        </div>

        <div>
            <PinDropIcon/>
            <input type="number" 
            placeholder='Pin Code'
            value={pinCode}
            required
            onChange={(e)=>setPinCode(e.target.value)}
            />
        </div>

        <div>
            <PhoneIcon/>
            <input type="number" 
            placeholder='Phone Number'
            required
            value={phoneNo}
            onChange={(e)=>setPhoneNo(e.target.value)}
            />
        </div>
{/* ya all countries pakege sa jo li haa */}
        <div>
            <PublicIcon/>
            <select 
            required
            value={country}
            onChange={(e)=>setCountry(e.target.value)}
            >
            <option value="">Country</option>
            {Country && Country.getAllCountries().map((item)=>(
                <option key={item.isoCode} value={item.isoCode}>
                    {item.name}
                </option>
            ))}
            </select>
        </div>
 {/* ya use state wali haa */}
        {country && (
            <div>
            <TransferWithinAStationIcon/>
            <select
            required
            value={state}
            onChange={(e)=>setState(e.target.value)}
            >
            <option value="">State</option>
            {State &&
            State.getStatesOfCountry(country).map((item)=>(
                <option key={item.isoCode} value={item.isoCode}>
                    {item.name}
                </option>
            ))
            }
            </select>
            </div>
        )}
        <input
        type='submit'
        value="Continue"
        className='shippingBtn'
        disabled={state ? false : true}
        >
        
        </input>


 </form>

        </div>
    </div>
    </>
  )
}

export default Shipping